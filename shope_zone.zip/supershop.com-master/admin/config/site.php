<?php
### Website Configuration
$GLOBALS['CURRENCY'] = "&#2547;" ;

### ADMINS IMAGE DIRECTORY
$GLOBALS['ADMINS_DIRECTORY'] = "../public/uploads/admins/";

### SLIDER IMAGE DIRECTORY
$GLOBALS['SLIDES_DIRECTORY'] = "../public/uploads/slides/";

### PRODUCT MASTER IMAGE DIRECTORY
$GLOBALS['PRODUCT_DIRECTORY'] = "../public/uploads/products/";

### ADDITIONAL PRODUCT IMAGE DIRECTORY
$GLOBALS['PRODUCTADD_DIRECTORY'] = "../public/uploads/prodaddimages/";

### SUBCATEGORY BANNER IMAGE DIRECTORY
$GLOBALS['BANNER_DIRECTORY'] = "../public/uploads/banners/";
?>
