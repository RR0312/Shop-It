<?php
### DATABASE CONFIGURATION
$GLOBALS['DBHOST'] = "localhost";
$GLOBALS['DBNAME'] = "supershop_rdb";
$GLOBALS['DBUSER'] = "root";
$GLOBALS['DBPASS'] = "";
?>